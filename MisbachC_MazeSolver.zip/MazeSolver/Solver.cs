﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeSolver
{
    public static class Solver
    {
        public static bool SolveShortest(AdjacencyList list, out string path)
        {
            path = "";

            List<string> listPath = new List<string>();
            for (int i = 0; i < list.List.Count; ++i)
            {
                if (list.List[i].Tag == list.Start)
                {
                    TraverseShortest(list.List[i], new List<string>(), ref listPath, list.End);
                    break;
                }
            }

            path = string.Join(",", listPath.ToArray());

            return !string.IsNullOrEmpty(path);
        }

        private static void TraverseShortest(Node current, List<string> path, ref List<string> route, string end)
        {
            if (path.Contains(current.Tag))
                return;

            path.Add(current.Tag);

            if (current.Tag == end)
            {
                if (route.Count == 0 || path.Count < route.Count)
                    route = path;
                return;
            }
            
            for (int i = 0; i < current.Near.Count; ++i)
            {
                TraverseShortest(current.Near[i], new List<string>(path), ref route, end);
            }
        }

        public static bool SolveAll(AdjacencyList list, string[] paths)
        {
            bool solved = false;



            return solved;
        }
    }
}
